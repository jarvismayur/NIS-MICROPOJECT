






function login(){
 var email = document.getElementById("email").value;
var password = document.getElementById("password").value;
alert(email+"/" +password);
if(email =="tembharemayur@gmail.com"){
  alert("Email Accepted");
  if(password == "mayur@123"){
    alert("password Accpeted")
    parent.location.replace("http://www.w3schools.com");
  }
}else{
  alert("ur are Not Authenticate");
}
}
